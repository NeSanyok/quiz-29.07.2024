import React from "react";

export const Header = ()=>{
  return(
    <h1>Добро пожаловать в квиз от лучшего учебного центра</h1>
  )
}